#ifndef COMMENT_H
#define COMMENT_H
#include "info.h"
#include "film.h"
#include "user.h"
class Comment 
{
public:
    Comment(Film* _related_film,int _id,User* _commenter);
    Film* get_related_film(){return related_film;}
    int get_id(){return id;}
    User* get_commenter(){return commenter;}
private:
    Film* related_film;
    int id;
    User* commenter;
};
#endif 