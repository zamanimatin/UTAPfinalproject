#include "commandprocessor.h"

string CommandProcessor::remove_spaces(string line)
{
    line.erase(remove(line.begin(), line.end(), ' '), line.end()); 
    return line;  
}
void CommandProcessor::general_process_command()
{
    string command;
    string query;
    command = this->get_from_commandline();
    query = this->return_query(command);
    query = this->put_mark_between_fields(query);
}
string CommandProcessor::put_mark_between_fields(string query)
{
    for(int i=0;i<query.size();i++)
    {
        if(query[i]==' ' && query[i+1]== ' ')
            query.erase(i,ONE);
    }
    for(int i=0;i<query.size();i++)
    {
        if(query[i]== ' ')
            query[i] = LINE_MARK;
    }
    return query;
}
string CommandProcessor::return_type_of_command(string command)
{
    string request = this->get_first_command(command);
    string type;
    for(int i=request.size();i<command.size();i++)
    {
        if(command[i]!=QUESTION_MARK)
            type += command[i];
        else if(command[i] == QUESTION_MARK)
            break;
    }
    return type;
}
string CommandProcessor::get_desired_info(string query,string info)
{
    string name;
    string desired;
    int i=0;
    while(i != query.size()- 1)
    {
        if(query[i]!= LINE_MARK)
            name += query[i];
        else if(name != info && query[i]==LINE_MARK)
        {
            name.clear();
        }
        else if(name == info)
        {
            query = query.substr(i);
            int j=1;
            while(query[j]!=LINE_MARK && j<query.size())
            {
                desired += query[j];
                j++;
            }
            return desired;
        }
        i++;
    }
}
static size_t CommandProcessor::hash_password(const char* password)
{
    size_t hash = 0;
    while (*cp)
        hash = (hash * 10) + *cp++ - '0';
    return hash;
}
string CommandProcessor::return_query(string command)
{
    int count = 0;
    for(int i=0;i<command.size();i++)
    {
        if(command[i]!=QUESTION_MARK)
            count++;
        else 
            break;
    }
    count++;
    command = command.substr(count);
    return command;
}
string CommandProcessor::get_from_commandline()
{   
    string input;
    getline(cin,input);
    return input;
}
string CommandProcessor::get_first_command(string input)
{
    string in;
    for(int i=0;i<SIX;i++)
    {
        if(in == PUT_STRING || in == GET_STRING)
            break;
        else if(in == POST_STRING)
            break;
        else if(in == DELETE_STRING)
            break;
        in += input[i];
    }   
    return in;
}
string CommandProcessor::get_second_command(string input)
{
    string first = this->get_first_command(input);
    string second;
    for(int i=0;i<input.size();i++)
        while(input[i]!=QUESTION_MARK)
        {
            if(first == GET_STRING || first == PUT_STRING)
                second += input[i+THREE];
            else if(first == POST_STRING)
                second += input[i+FOUR];
            else if(first == DELETE_STRING)
                second += input[i+SIX];
        }
    return second;
}
bool CommandProcessor::is_valid_command(string command)
{
    command = this->remove_spaces(command);
    if(this->is_valid_first_part(command)&&this->is_valid_q_mark(command))
        return true;
    throw WrongRequest();
    return false;
}
bool CommandProcessor::is_valid_first_part(string command)
{
    int size;
    command.erase(command.begin()+SIX,command.end());
    size = command.size();
    switch(size)
    {
        case THREE:
            if(command == PUT_STRING || command == GET_STRING)
                return true;
        break;
        case FOUR:
            if(command == POST_STRING)
                return true;
        break;
        case SIX:
            if(command == DELETE_STRING)
                return true;
        break;
        default:
            return false;
            break;
    }
}
bool CommandProcessor::signup_check(string command)
{
    string query = this->return_query(command);
    string username = this->get_desired_info(query,"username");
    string password = this->get_desired_info(query,"password");
    for(int i=0;i<central_manager->concat_user_vectors().size();i++)
    {
        if(central_manager->concat_user_vectors()[i]->get_username() == username)
        {
            throw WrongRequest();
            return false;
        }
    }
}   
bool CommandProcessor::is_valid_q_mark(string command)
{
    int size;
    command.erase(command.begin()+SEVEN,command.end());
    size = command.size();
    switch(size)
    {
        case FOUR:
            if(command[THREE]==QUESTION_MARK)
                return true;
        break;
        case FIVE:
            if(command[FOUR] == QUESTION_MARK)
                return true;
        break;
        case SEVEN:
            if(command[SIX] == QUESTION_MARK)
                return true;
        break;
        default:
        return false;
        break;
    }
}
void CommandProcessor::make_add_new_user(string command,MI& central_info)
{
    string query = this->return_query(command);
    bool sit = this->check_user_sit(query);
    if(sit==true)
    {
        vector<Film*> publisher_buy_film;
        vector<Message*> publisher_rec_message;
        vector<Message*> publisher_sent_message;
        vector<User*> publisher_followers;
        vector<Film*> publisher_sent_film;
        Publisher* newpub;
        newpub = new Publisher(central_info.central_client_id,this->get_desired_info(query,"username")
                ,this->hash_password(this->get_desired_info(query,"password")),
                this->get_desired_info(query,"email"),
                (int)this->get_desired_info(query,"age"),ZERO,publisher_buy_film,
        publisher_rec_message,publisher_sent_message,publisher_sent_film,publisher_followers);
        central_manager->add_a_publisher_to_data_base(newpub);
        this->change_central_info(central_info,CENTRAL_CLIENT_ID);
        this->change_central_info(central_info,SYSTEM_SIT);
        cout<<"OK"<<endl;
    }
    else if(sit == false)
    {
        vector<Film*> _bought_films;
        vector<Message*> _recieved_messages;
        vector<Message*> _sent_messsages;
        vector<User*> _followed_publishers;
        Customer* newcus = new Customer(central_info.central_client_id,this->get_desired_info(query,"username"),
        this->hash_password(this->get_desired_info(query,"password")),this->get_desired_info(query,"email"),
        (int)this->get_desired_info(query,"age"),ZERO,
        _bought_films,_recieved_messages,_sent_messages,_followed_publishers);
        central_manager->add_a_customer_to_data_base(newcus);
        this->change_central_info(central_info,CENTRAL_CLIENT_ID);
        this->change_central_info(central_info,SYSTEM_SIT);
        cout<<"OK"<<endl;
    }
}
bool CommandProcessor::check_user_sit(string query)
{
    string sit = this->get_desired_info(query,"publisher");
    if(sit.size()==0 || sit== "false")
        return false;
    else if(sit.size()!=0&&sit == "true")
        return true;
}
void CommandProcessor::run_entered_command(string command)
{
    if(this->get_first_command(command)==POST_STRING && this->return_type_of_command(command)=="signup")
    {
        try
        {
            this->make_add_new_user(command);
        }catch(exception& ex)
        {
            cerr<<ex.what()<<endl;
        }
    }
    else if(this->get_first_command(command)==POST_STRING && this->return_type_of_command(command)=="login")
    {
        try
        {
            this->login_user(command);    
        }catch(exception& ex)
        {
            cerr<<ex.what()<<endl;
        }
    }
    else if()
    {
        try
        {
            
        }catch(exception& ex)
        {
            cerr<<e.what()<<endl;
        }
    }
}
bool CommandProcessor::login_check(string command)
{
    string query = this->return_query(command);
    string username = this->get_desired_info(query,"username");
    string password = this->get_desired_info(query,"password");
    size_t hashed_password = this->hash_password(password.c_str());
    for(int i=0;i<central_manager->concat_user_vectors().size();i++)
    {
        if(central_manager->concat_user_vectors()[i]->get_username() == username)
        {
            if(central_manager->concat_user_vectors()[i]->get_password == password)
                return true;
            return false;
        }
    }
    throw WrongRequest();
}
void CommandProcessor::login_user(MI& central_info,string username)
{
    central_manager->change_central_info(central_info,SYSTEM_SIT);
    for(int i=0;i<central_manager->get_data_base_all_publishers().size();i++)
    {
        if(username == central_manager->get_data_base_all_publishers()[i]->get_username())
        {
            central_manager->set_client_data(central_manager->get_data_base_all_publishers()[i]->get_id(),
            central_manager->get_data_base_all_publishers()[i]->get_username(),
            central_manager->get_data_base_all_publishers()[i]->get_password(),
            central_manager->get_data_base_all_publishers()[i]->get_email(),
            central_manager->get_data_base_all_publishers()[i]->get_age(),true);
            cout<<"OK"<<endl;
            return ;
        }
    }       
    for(int i=0;i<central_manager->get_data_base_all_customers().size();i++)
    {
        if(username == central_manager->get_data_base_all_customers()[i]->get_username())
        {
            central_manager->set_client_data(central_manager->get_data_base_all_customers()[i]->get_id(),
            central_manager->get_data_base_all_customers()[i]->get_username(),
            central_manager->get_data_base_all_customers()[i]->get_password(),
            central_manager->get_data_base_all_customers()[i]->get_email(),
            central_manager->get_data_base_all_customers()[i]->get_age(),false);
            cout<<"OK"<<endl;
            return ;
        }
    }
    throw WrongRequest();
}