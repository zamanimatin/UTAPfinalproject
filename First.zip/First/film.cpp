#include "film.h"
Film::Film(User* _owner,string _name,int _id,float _rate,int _price,int _year,string _director,
int _length,string _summary,vector<Comment*> _list_of_comments)
{
    owner = _owner;
    name = _name;
    id = _id;
    rate = _rate;
    price = _price;
    year = _year;
    director = _director;
    length = _length;
    summary = _summary;
    list_of_comments = _list_of_comments;
}
void Film::add_a_comment(Comment* c)
{
    list_of_comments.push_back(c);
}
void Film::change_film_info(string film_name,int film_year ,int film_length,string film_summary,string film_director)
{
    if(filename != 0 )
        name = film_name;
    if(film_year != 0)
        year = film_year;
    if(film_length != 0)
        length = film_length;
    if(film_summary != 0)
        summary = film_summary;
    if(film_director != 0)
        director = film_director;
}
int Film::get_film_situation()
{
    if(rate < FIVE)
        return AWFUL;
    else if(rate >= FIVE &&rate < EIGHT)
        return GOOD;
    else if(rate >= EIGHT)
        return GREAT;
}
int Film::calc_publisher_share()
{
    switch(this->get_film_situation())
    {
        case AWFUL:
            return EIGHTY_PERCENT * price;
        break;
        case GOOD:
            return NINTY_PERCENT * price;
        break;
        case GREAT:
            return NINTY_FIVE_PERCENT * price;
        break;
    }
}