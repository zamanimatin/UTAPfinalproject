#include "user.h"
User::User(int _id,string _user_name,int _password,string _email,int _age,int _money,
vector<Film*> _bought_films,vector<Message*> _recieved_messages,vector<Message*> _sent_messages)
{
    id = _id;
    user_name = _user_name;
    password = _password;
    email = _email;
    age = _age;
    money = _money;
    bought_films = _bought_films;
    recieved_messages = _recieved_messages;
    sent_messages = _sent_messages;
}
void User::add_bought_film(Film* f)
{
    User* film_publisher = f->get_owner();
    int publisher_share = f->calc_publisher_share();
    film_publisher->increase_money(publisher_share);
    bought_films.push_back(f);
}
void User::increase_money(int m)
{
    money+=m;
}
void User::add_recieved_message(Message* m)
{
    recieved_messages.push_back(m);
}
void User::add_sent_message(Message* m)
{
    sent_messages.push_back(m);
}
