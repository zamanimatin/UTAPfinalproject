#ifndef COMMANDPROCESSOR_H
#define COMMANDPROCESSOR_H
#include "info.h"
#include "manager.h"
#include "exceptions.h"
#include <string>
#include <functional>
using namespace std;
class CommandProcessor 
{
public:
    void set_manger(Manager* m){central_manager = m;}
    void general_process_command();
    string remove_spaces(string line);
    string get_from_commandline();
    string get_first_command(string input);
    string get_second_command(string input);
    string return_query(string command);
    string return_type_of_command(string command);
    string put_mark_between_fields(string command);
    string get_desired_info(string query,string info);
    void make_add_new_user(string command);
    bool check_user_sit(string query);
    long unsigned int hash_password(string password);
    bool signup_check(string command);
    bool is_valid_command(string command);
    bool is_valid_first_part(string command);
    bool is_valid_q_mark(string command);
    void run_entered_command();
    void login_user(string command);
    bool login_check(string command,string username);
    
protected:
    Manager* central_manager;

};
#endif