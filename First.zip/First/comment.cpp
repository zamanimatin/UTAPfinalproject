#include "comment.h"
Comment::Comment(Film* _related_film,int _id,User* _commenter)
{
    related_film = _related_film;
    id = _id;
    commenter = _commenter;
}