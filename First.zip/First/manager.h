#ifndef MANAGER_H
#define MANAGER_H
#include "info.h"
#include "film.h"
#include "user.h"
#include "publisher.h"
#include "customer.h"
#include "message.h"
#include "comment.h"
class Manager
{
public:
    
    void add_a_film_to_data_base(Film* f);
    void add_a_publisher_to_data_base(Publisher* p);
    void add_a_customer_to_data_base(Customer* c);
    void add_a_message_to_data_base(Message* m);
    void add_a_comment_to_data_base(Comment* c);
    bool user_exists_with_name(string username);
    void change_central_info(MI central_info,string data);
    void set_client_data(int id,string username,int password,
    string email,int age,bool publisher_client_sit = false);
    vector<Film*> get_data_base_all_films(){return data_base_all_films;}
    vector<Publisher*> get_data_base_all_publishers(){return data_base_all_publishers;}
    vector<Customer*> get_data_base_all_customers(){return data_base_all_customers;}
    vector<Message*> get_data_base_all_messages(){return data_base_all_messages;}
    vector<Comment*> get_data_base_all_comments(){return data_base_all_comments;}
    void set_data_base_info(vector<Film*> newfilms,vector<Publisher*> newpublishers,
    vector<Customer*> newcustomers,vector<Message*> newmessages,vector<Comment*> newcomments);
    vector<User*> concat_user_vectors();
protected:
    vector<Film*> data_base_all_films;
    vector<Publisher*> data_base_all_publishers;
    vector<Customer*> data_base_all_customers;
    vector<Message*> data_base_all_messages;
    vector<Comment*> data_base_all_comments;
    int client_id;
    string client_username;
    int client_password;
    string client_email;
    string client_age;
    bool client_publisher_sit;
};
#endif