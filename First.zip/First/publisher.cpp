#include "publisher.h"
Publisher::Publisher(int _id,string _user_name,int _password,string _email,int _age,int _money,
vector<Film*> _bought_films,vector<Message*> _recieved_messages,
vector<Message*> _sent_messages,vector<Film*> _uploaded_films,vector<User*> _followers) : 
User(_id,_user_name,_password,_email,_age,_money,_bought_films,_recieved_messages,_sent_messages)
{
    uploaded_films = _uploaded_films;
    followers = _followers;
}
void Publisher::add_an_uploaded_film(Film* f)
{
    uploaded_films.push_back(f);
    //here a message should be sent to this publisher followers
}
void Publisher::add_a_follower(User* f)
{
    followers.push_back(f);
    //here a message should be sent to this publisher
}
void Publisher::show_list_of_followers()
{
    this->sort_followers_by_id();
    cout<<"List of Followers"<<endl;
    cout<<"#. User Id | User Username | User Email"<<endl;
    for(int i=0;i<followers.size();i++)
    {
        cout<<i+1<<". "<<followers[i]->get_id()<<
        " | "<<followers[i]->get_username()<<" | "<<followers[i]->get_email()<<endl;
    }
}
void Publisher::sort_followers_by_id()
{
    std::sort(followers.begin(), followers.end(), [](User* a, User* b){
        return a->get_id() < b->get_id();
    });
}
void Publisher::delete_a_film_from_uploaded(int id)
{
    for(int i=0;i<uploaded_films.size();i++)
        if(uploaded_films[i]->get_id() == id)
        {
            uploaded_films.erase(uploaded_films.begin()+ i);
            cout<<"OK"<<endl;
            return;
        }
    throw ExistenceError();
}
void Publisher::edit_a_film(int film_id,string film_name = 0,
int film_year = 0,int film_length = 0,string film_summary = 0,string film_director = 0)
{
    for(int i=0;i<uploaded_films.size();i++)
    {
        if(uploaded_films[i]->get_id() == film_id)
        {   
            uploaded_films[i]->change_film_info(film_name,film_year,film_length,film_summary,film_director);
        }
    }
    throw AccessError();
}