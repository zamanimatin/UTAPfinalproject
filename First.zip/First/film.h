#ifndef FILM_H
#define FILM_H
#include "info.h"
#include "user.h"
#include "comment.h"
class Film
{
public:
    Film(User* _owner,string _name,int _id,float _rate,int _price,int _year,string _director,
    int _length,string _summary,vector<Comment*> _list_of_comments);
    void change_film_info(string film_name,int film_year,
    int film_length,string film_summary,string film_director);
    int get_film_situation();
    int calc_publisher_share();
    User* get_owner(){return owner;}
    string get_name(){return name;}
    int get_id(){return id;}
    float get_rate(){return rate;}
    int get_price(){return price;}
    int get_year(){return year;}
    string get_director(){return director;}
    int get_lenght(){return length;}
    vector<Comment*> get_list_comments(){return list_of_comments;}
    void add_a_comment(Comment* c);
private:
    User* owner;
    string name;
    int id;
    float rate;
    int price;
    int year;
    string director;
    int length;
    string summary;
    vector<Comment*> list_of_comments;
};
#endif