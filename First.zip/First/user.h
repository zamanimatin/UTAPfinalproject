#ifndef USER_H
#define USER_H
#include "info.h"
#include "film.h"
#include "message.h"
#include "exceptions.h"
class User 
{
public:
    User(int id,string user_name,int password,string email,int age,int money,
    vector<Film*> bought_films,vector<Message*> recieved_messages,vector<Message*> sent_messages);
    void add_bought_film(Film* f);
    void increase_money(int m);
    void add_recieved_message(Message* m);
    void add_sent_message(Message* m);
    int get_id(){return id;}
    string get_username(){return user_name;}
    int get_password(){return password;}
    string get_email(){return email;}
    int get_money(){return money;}
    vector<Film*> get_bought_films(){return bought_films;}
    vector<Message*> get_recieved_messages(){return recieved_messages;}
    vector<Message*> get_sent_messages(){return sent_messages;}
protected:
    int id;
    string user_name;
    int password;
    string email;
    int age;
    int money;
    vector<Film*> bought_films;
    vector<Message*> recieved_messages;
    vector<Message*> sent_messages;
};
#endif