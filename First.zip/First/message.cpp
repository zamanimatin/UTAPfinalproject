#include "message.h"
Message::Message(int _id,User* _sender,User* _reciever,string _content)
{
    id = _id;
    sender = _sender;
    reciever = _reciever;
    content = _content;
}