#include "manager.h"
void Manager::add_a_film_to_data_base(Film* f)
{
    data_base_all_films.push_back(f);
}
void Manager::add_a_publisher_to_data_base(Publisher* p)
{
    data_base_all_publisher.push_back(p);
}
void Manager::set_client_data(int id,string username,int password,string email,int age,bool _sit = false)
{
    client_id = id;
    client_username = username;
    client_password = password;
    client_age = age;
    client_email = email;
    client_publisher_sit = _sit;
}
void Manager::add_a_customer_to_data_base(Customer* c)
{
    data_base_all_customers.push_back(c);
}
void Manager::add_a_message_to_data_base(Message* m)
{
    data_base_all_messages.push_back(m);
}
void Manager::add_a_comment_to_data_base(Comment* c)
{
    data_base_all_comments.push_back(c);
}
bool Manager::user_exists_with_name(string username)
{
    for(int i=0 ;i<data_base_all_customers.size();i++)
        if(data_base_all_customers[i]->get_username() == username)
            return true;
    for(int i=0;i<data_base_all_publishers.size();i++)
        if(data_base_all_publishers[i]->get_username() == username)
            return true;
    return false;
}
void Manager::set_data_base_info(vector<Film*> newfilms,vector<Publisher*> newpublishers
,vector<Customer*> newcustomers,vector<Message*> newmessages,vector<Comment*> newcomments)
{
    data_base_all_films = newfilms;
    data_base_all_publishers = newpublishers;
    data_base_all_customers = newcustomers;
    data_base_all_messages = newmessages;
    data_base_all_comments = newcomments;
}   
void Manager::change_central_info(MI central_info,string data)
{
    switch(data)
    {
        case CENTRAL_CLIENT_ID:
            central_info.central_client_id++;
        break;
        case CENTRAL_FILM_ID:
            central_info.central_film_id++;
        break;
        case CENTRAL_COMMENT_ID :
            central_info.central_comment_id++;
        break;
        case CENTRAL_MESSAGE_ID: 
            central_info.central_message_id++;
        break;
        case SYSTEM_SIT: 
        {
            if(central_info.system_sit==true)
                centra_info.system_sit = false;
            else
                centra_info.system_sit = true;
        }
        break;
    }
}
vector<User*> Manager::concat_user_vectors()
{
    vector<User*> all_users;
    for(int i=0;i<data_base_all_publishers.size();i++)
        all_users.push_back(data_base_all_publishers[i]);
    for(int i=0;i<data_base_all_customers.size();i++)
        all_users.push_back(data_base_all_customers[i]);
    return all_users;
}