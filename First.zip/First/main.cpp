#include <iostream>
#include <string>
#include <vector>
#include "info.h"
#include "user.h"
#include "publisher.h"
#include "customer.h"
#include "manager.h"
#include "commandprocessor.h"
#include "comment.h"
#include "exceptions.h"
#include "film.h"

using namespace std;
#include "message.h"

int main()
{
    MI central_info; 
    Manager main_manager;
    CommandProcessor* main_handler = new CommandProcessor();
    main_handler->general_process_command();
    return 0;
}