#ifndef PUBLISHER_H
#define PUBLISHER_H
#include "info.h"
#include "film.h"
#include "user.h"
#include "exceptions.h"
class ExistenceError;
class AccessError;
class Publisher : public User
{
public:
    Publisher(int id,string user_name,int password,string email,int age,int money,
    vector<Film*> bought_films,vector<Message*> recieved_messages,
    vector<Message*> sent_messages,vector<Film*> uploaded_films,vector<User*> followers);
    void add_an_uploaded_film(Film* f);
    void add_a_follower(User* f);
    void show_list_of_followers();
    void sort_followers_by_id();
    void delete_a_film_from_uploaded(int id);
    void edit_a_film(int film_id,string film_name,int film_year,int film_length,string film_summary,string film_director);
    
    
    //a function to sent messages for followers
    
    vector<Film*> get_uploaded_films(){return uploaded_films;} 
    vector<User*> get_followers(){return followers;}
    const string get_type(){return type;}
private:
    const string type = "Publisher";
    vector<Film*> uploaded_films;
    vector<User*> followers;
};
#endif