#ifndef MESSAGE_H
#define MESSAGE_H
#include "info.h"
#include "user.h"
class User;
class Message
{
public:
    Message(int _id,User* _sender,User* _reciever,string _content);
    int get_id(){return id;}
    User* get_sender(){return sender;}
    User* get_reciever(){return reciever;}
    string get_content(){return content;}
private:
    int id;
    User* sender;
    User* reciever;
    string content;
    //shall be a time field here
};
#endif